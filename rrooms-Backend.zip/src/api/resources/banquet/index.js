export { banquetRouter } from './banquet.route';

